// ignore_for_file: camel_case_types

class quizmodel {
  String? question;
  Map<String, bool>? answers;
  quizmodel(this.question, this.answers);
}