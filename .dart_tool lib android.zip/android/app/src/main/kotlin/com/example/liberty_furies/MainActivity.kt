package com.example.liberty_furies

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
