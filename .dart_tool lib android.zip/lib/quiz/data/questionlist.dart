import '../model/quizmodel.dart';

List<quizmodel> questions = [
  quizmodel(
    "How Many Whiskers does the average cat have on each side of its face ?",
    {
      "Arti Gupta": true,
      "Sneh Singh": false,
      "Ujwala Rai": false,
      "None of the above": false,
    },
  ),
  quizmodel("Youngest woman to climb Mount Everest two times in India?", {
    "Omana": false,
    "Faria": false,
    "Dicky Dolma": true,
    "None of the above": false,
  }),
  quizmodel("First woman to pass MA in India?", {
    "Leila Seth": false,
    "Chandra Mukhi Bose": true,
    "Thresia": false,
    "Kadambani Bose": false,
  }),
  quizmodel("Name the first woman who become doctor on India?", {
    "Anita Bose": false,
    "Ujwala Rai": false,
    "Kadambani Ganguli": true,
    "Cornelia Sorabji": false,
  }),
  quizmodel("First woman to circumnavigate around the world?", {
    "Ujwala Rai": true,
    "Anna George": false,
    "Sucheta Kriplani": false,
    "None of the above": false,
  }),
  quizmodel("First woman who recieved a Sena Medal in India :- ", {
    "Santosh Yadav": false,
    "Dicky Dolma": false,
    "Bimla Devi": true,
    "Kiran Devi": false,
  }),
  quizmodel(
      "Name the first woman who become the speaker of Lok Sabha in India ?", {
    "Mrs Sarojini Naidu": false,
    "Leila Seth": false,
    "Reita Feria": false,
    "Mrs Shanno Devi": true,
  }),
  quizmodel("First woman editor of English newspaper in India ?", {
    "Anna Chandi": false,
    "P.K Thresia": false,
    "Dina Vakil": true,
    "None of the above": false,
  }),
  quizmodel(
      "Name the first woman who become the advocate in India?",
      {
        "Kamla Devi": false,
        "Arti Shah": false,
        "Cornelia Sarabji": true,
        "None of the above": false,
      }),
  quizmodel(
      "The woman who become the first IAS officer in India?", {
    "Kiran Bedi": false,
    "Anna George Malhotra": true,
    "M. Fatima Biwi": false,
    "None of the above": false,
  }),
  quizmodel(
      "Who is the first Indian women to win  the WTA title?", {
    "Shaina Nehwal": false,
    "Sania Mirza": true,
    "Mary Kom": false,
    "Matina Hingis": false,
  }),
  quizmodel(
      "Who is the first women to fly among space?", {
    "Kalpana Chawla": false,
    "Valentina Terreshkova": true,
    "Shanon Lucid": false,
    "Shunita Williams": false,
  }),
];
